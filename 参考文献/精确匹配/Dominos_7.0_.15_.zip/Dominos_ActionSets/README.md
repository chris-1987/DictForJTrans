## Dominos ActionSets

This addon extends Dominos profiles to support saving and loading of action button placements.
