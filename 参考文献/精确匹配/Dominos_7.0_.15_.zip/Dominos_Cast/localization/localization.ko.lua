﻿--[[
	localization.koKR.lua
	translated & modified by SayClub
]]

local L = LibStub('AceLocale-3.0'):NewLocale('Dominos-CastBar', 'koKR')
if not L then return end

L.Texture = '무늬'
L.Width = '너비'
L.Height = '높이'
L.ShowTime = '시간 표시'
L.Padding = '열 간격'
